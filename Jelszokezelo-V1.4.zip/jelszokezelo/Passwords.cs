﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jelszokezelo
{
    struct Passwords
    {
        public string username;
        public string email;
        public string password;
        public string website;
    }
}
