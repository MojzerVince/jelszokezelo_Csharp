# Password Manager C# Project
An app storing **TOP SECRET** password information

## Features:
* Password generation with numbers, lower/uppercase and special characters
* PIN generation
* Pass modification
* Custom pass input

### Devs:
* Mojzer Vince
* Király Marcell
